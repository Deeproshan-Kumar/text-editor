const body = document.body,
  textarea = document.querySelector('.textarea'),
  fontSize = document.querySelector('#font-size'),
  fontWeight = document.querySelector('#font-weight'),
  fontFamily = document.querySelector('#font-family'),
  printDoc = document.querySelector('#print'),
  copyText = document.querySelector('#copy-text'),
  bold = document.querySelector('.bold'),
  italic = document.querySelector('.italic'),
  underline = document.querySelector('.underline'),
  left = document.querySelector('.left'),
  center = document.querySelector('.center'),
  right = document.querySelector('.right'),
  date = document.querySelector('.date'),
  time = document.querySelector('.time'),
  total = document.querySelector('.total'),
  wpm = document.querySelector('.wpm'),
  dayNightMode = document.querySelector('#dayNightMode'),
  subscript = document.querySelector('.subscript'),
  superscript = document.querySelector('.superscript');

const changeFontSize = () => (textarea.style.fontSize = `${fontSize.value}px`);

const changefontWeight = () =>
  (textarea.style.fontWeight = `${fontWeight.value}`);

const changefontFamily = () =>
  (textarea.style.fontFamily = `${fontFamily.value}`);

const printDocument = () => window.print();

const boldText = () => (textarea.style.fontWeight = 'bold');

const italicText = () => (textarea.style.fontStyle = 'italic');

const underlineText = () => (textarea.style.textDecoration = 'underline');

const leftAlign = () => (textarea.style.textAlign = 'left');

const centerAlign = () => (textarea.style.textAlign = 'center');

const rightAlign = () => (textarea.style.textAlign = 'right');

const copyDocText = () => {
  textarea.select();
  textarea.setSelectionRange(0, 99999);
  navigator.clipboard.writeText(textarea.value);
};

// Date and Time
setInterval(function getTime() {
  let dt = new Date();
  let currTime = `${dt.getHours() < 10 ? '0' + dt.getHours() : dt.getHours()} : 
    ${dt.getMinutes() < 10 ? '0' + dt.getMinutes() : dt.getMinutes()} : 
    ${dt.getSeconds() < 10 ? '0' + dt.getSeconds() : dt.getSeconds()}`;
  time.textContent = currTime;
}, 1000);

let currDate = new Date();
let months = [
  'Jan',
  'Feb',
  'March',
  'April',
  'May',
  'June',
  'July',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];
let formatedDate = `${currDate.getDate()} ${
  months[currDate.getMonth()]
}, ${currDate.getFullYear()}`;
date.textContent += formatedDate;

const calculate = () => {
  let chars = textarea.value.length;
  let words = textarea.value.split(' ').length;
  let lines = textarea.value.split('\n').length;
  let paragraphs = textarea.value.split('.').length;
  total.innerHTML = `Characters : <strong>${chars}</strong> 
    Words : <strong>${words}</strong> 
    Lines : <strong>${lines}</strong> 
    Paragraphs : <strong>${paragraphs}</strong>`;
};

dayNightMode.addEventListener('click', function () {
  body.classList.toggle('dark');
});

const subScript = () => alert('This functionality is under development...!');

const supScript = () => alert('This functionality is under development...!');

fontSize.addEventListener('change', changeFontSize);
fontWeight.addEventListener('change', changefontWeight);
fontFamily.addEventListener('change', changefontFamily);
printDoc.addEventListener('click', printDocument);
bold.addEventListener('click', boldText);
italic.addEventListener('click', italicText);
underline.addEventListener('click', underlineText);
copyText.addEventListener('click', copyDocText);
left.addEventListener('click', leftAlign);
center.addEventListener('click', centerAlign);
right.addEventListener('click', rightAlign);
textarea.addEventListener('keydown', calculate);
subscript.addEventListener('click', subScript);
superscript.addEventListener('click', supScript);
